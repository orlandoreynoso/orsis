<div class="searchbar">
	<form name="search" method="get" action="<?php bloginfo('url'); ?>/">
		<input type="text" class="cuadro_input" name="s" value="">
		<input class="buscando" type="submit" name="submit" value="Buscar">
	</form>	
</div>