<header>
	<div class="head-portada">
	<div class="contenedor">
		<?php  menuPrincipal();   ?>
		<div class="contenedor-texto">
			<div class="texto">
				<h1 class="nombre"><?php bloginfo('name'); ?></h1>
				<h2 class="profesion"><?php bloginfo('description'); ?></h2>
			</div>
		</div>
	</div>
	</div>
</header>