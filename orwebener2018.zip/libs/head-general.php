<div class="contok">
<header>
	<div class="head-general">
	<div class="contenedor">
		<div class="titulo-web"><a href="<?php bloginfo('url'); ?>/">Orlando Reynoso</a></div>
		<?php  menuPrincipal();   ?>	
	</div>
	</div>
</header>